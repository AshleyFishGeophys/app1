text = input("Enter a title:")

print(f"The length of the title is: {len(text)}")