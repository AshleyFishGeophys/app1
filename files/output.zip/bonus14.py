import shutil

shutil.make_archive("../files/output", "zip")
